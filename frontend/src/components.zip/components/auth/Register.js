import React, { Component } from 'react'

class Register extends Component {
  render() {
    return <div>Register</div>
  }
}

export default Register
